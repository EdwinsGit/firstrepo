# Revise baseline 6 again, 
# > Consider merging pay_05, pay_04, pay_06 - it doesn't make sense for them to mess up in order indicates low importance 
# > Consider removing bill_increase 2,3,4 as we have observed they were no difference in partial dependency plot -> nope
# > pay 6 and pay 5 counts we can also consider removing. -> no effect
# pay_0 5 and 6 could be merged as well

# Load Libraries ----
library(here)
library(tidyverse)
library(janitor)
library(caret)
library(gbm)
library(ROCR)
library(parallel)
library(doParallel)
library(pROC) # For calculating AUC

# Load data sets ----
credit_data <- read_csv(here("data", "AT2_credit_train.csv"))
credit_test <- read_csv(here("data", "AT2_credit_test.csv"))
credit_data <- read_csv("v7.train.csv")
temp_data <- read_csv("v7.train.csv")

cluster = makeCluster(detectCores() - 2) # convention to leave 1 core for OS
registerDoParallel(cluster)
cluster

# Cleaning ----
get_pay_amount_fluctuations <- function(row_data, up){
  pay_amt_up = 0
  pay_amt_down = 0
  pay_amt_variables <- c("pay_amt1","pay_amt2","pay_amt3","pay_amt4","pay_amt5","pay_amt6")
  counter = length(pay_amt_variables)
  while(counter > 1){
    if(row_data[pay_amt_variables[counter]] - row_data[pay_amt_variables[counter-1]] > 0){
      pay_amt_up = pay_amt_up + 1
    } else if(row_data[pay_amt_variables[counter]] - row_data[pay_amt_variables[counter-1]] < 0){
      pay_amt_down = pay_amt_down + 1
    }
    counter = counter - 1
  }
  
  if(up){
    return(pay_amt_up)
  } else {
    return(pay_amt_down)
  }
}

get_pay_fluctuations <- function(row_data, up){
  pay_up = 0
  pay_down = 0
  pay_variables <- c("pay_0", "pay_2", "pay_3", "pay_4", "pay_5", "pay_6")
  counter = length(pay_variables)
  while(counter > 1){
    previousWeek <- 0
    currentWeek <- 0
    
    if(row_data[pay_variables[counter]] > 0){
      previousWeek <- 1
    }
    if(row_data[pay_variables[counter-1]] > 0){
      currentWeek <- 1
    }
    
    if(previousWeek - currentWeek > 0){
      pay_up = pay_up + 1
    } else if(previousWeek - currentWeek < 0){
      pay_down = pay_down + 1
    }
    counter = counter - 1
  }
  
  if(up){
    return(pay_up)
  } else {
    return(pay_down)
  }
}

get_total_value <- function(row_data, value){
  count = 0
  for(data in row_data){
    if(data == value){
      count = count + 1
    }
  }
  return(count)
}

transform4 <- function(temp_data, keep_id){
  # Basic Clean ----
#  temp_data <- temp_data %>%
#    clean_names() %>% 
#    filter(sex==1|sex==2) %>% #-------------- Task 5 & 6: Remove the few bad sex records
#    filter(limit_bal>=0) %>% #---------------- Remove negative credit
#    filter(age < 100) # ---------------------- %>% # Age 157 might be some kind of typo
  
  if(!keep_id){
    temp_data <- temp_data %>%
      select(-id) #------------------------ TASK 4: ID is present, so we need to just drop that column as well
#    temp_data$default <- as.factor(temp_data$default)
  }
  
  # pay amount ----
  # Because based on importance, it is the least important we want to make some
  # more meaning out of it - because it should at some level indicate defaulting
  pay_amt_variables <- c("pay_amt1","pay_amt2","pay_amt3","pay_amt4","pay_amt5","pay_amt6")
  pay_variables <- c("pay_0", "pay_2", "pay_3", "pay_4", "pay_5", "pay_6")
  temp_data <- temp_data %>%
    mutate_at(pay_amt_variables, .funs = function(x) replace(x, x > 0, 1)) %>%
    mutate(repayments = rowSums(across(pay_amt_variables)))
  
  # pay amount fluctuations
  temp_data <- temp_data %>%
    mutate(pay_amt_up = apply(across(pay_amt_variables), 1, function(x) get_pay_amount_fluctuations(x, TRUE))) %>%
    mutate(pay_amt_down = apply(across(pay_amt_variables), 1, function(x) get_pay_amount_fluctuations(x, FALSE)))
  
  
  # bill amount ----
  # bill increase and bill amount average instead of bill amount ----
  temp_data <- temp_data %>%
    mutate(bill_increase1 = get("bill_amt1")-get("bill_amt2")) %>%
    mutate(bill_increase2 = get("bill_amt1")-get("bill_amt3")) %>%
    mutate(bill_increase3 = get("bill_amt1")-get("bill_amt4")) %>%
    mutate(bill_increase4 = get("bill_amt1")-get("bill_amt5")) %>%
    mutate(bill_increase5 = get("bill_amt1")-get("bill_amt6")) %>%
    mutate(bill_average = rowMeans(across(starts_with("bill_amt"))))
  
  
  # merged_pay_count_variables <- c("pay_5_count", "pay_6_count")
  
  temp_data<- temp_data %>% 
    mutate(pay_n2_count = apply(across(pay_variables), 1, function(x) get_total_value(x, -2))) %>%
    mutate(pay_n1_count = apply(across(pay_variables), 1, function(x) get_total_value(x, -1))) %>%
    mutate(pay_0_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 0))) %>%
    mutate(pay_1_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 1))) %>%
    mutate(pay_2_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 2))) %>%
    mutate(pay_3_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 3))) %>%
    mutate(pay_4_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 4))) %>%
    mutate(pay_5_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 5))) %>%
    mutate(pay_6_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 6)))
  # mutate(pay_5plus_count = rowSums(across(merged_pay_count_variables)))
  
  # pay X ----
  
  # pay fluctuations
  temp_data <- temp_data %>%
    mutate(pay_up = apply(across(pay_variables), 1, function(x) get_pay_fluctuations(x, TRUE))) %>%
    mutate(pay_down = apply(across(pay_variables), 1, function(x) get_pay_fluctuations(x, FALSE)))
  
  # credit score 1
  temp_data <- temp_data %>%
    mutate(credit_score1 = rowSums(across(pay_variables)))
  
  # credit score 2 - based on -2 could indicate inactivity which is bad
  temp_data <- temp_data %>%
    mutate_at(pay_variables, .funs = function(x) replace(x, x == -1, -3)) %>%
    mutate_at(pay_variables, .funs = function(x) replace(x, x == 0, -1)) %>%
    mutate_at(pay_variables, .funs = function(x) replace(x, x == -2, 0)) %>%
    mutate_at(pay_variables, .funs = function(x) replace(x, x == -3, -2)) %>%
    mutate(credit_score2 = rowSums(across(pay_variables)))
  
  # Merging 6 into 5 essentially removing 6
  temp_data <- temp_data %>%
    mutate_at("pay_0", .funs = function(x) replace(x, x == 6, 5))
  
  # pay amount is also now a categorical variable
  categorical_variables <- c("marriage", "sex", "education", pay_amt_variables, pay_variables)
  
  temp_data[,categorical_variables] <- lapply(temp_data[,categorical_variables], factor)
  
  pay_variables_overfitting <- c("pay_2", "pay_3", "pay_4", "pay_5", "pay_6")
  bill_amount_overfitting <- c("bill_amt3", "bill_amt4", "bill_amt5", "bill_amt6")
  overfitting_pay_count_variables <- c("pay_5_count", "pay_6_count")
  
  overfitting_variables <- c(pay_amt_variables, pay_variables_overfitting, bill_amount_overfitting, overfitting_pay_count_variables)
  temp_data <- temp_data %>%
    select(-overfitting_variables)
  
#  temp_data <- temp_data %>%
#    relocate(default)
  
  return(temp_data)
}

credit_data <- transform4(credit_data, FALSE)
credit_data <- credit_data %>% relocate(default, .after = last_col())
#credit_data$default <- as.numeric(credit_data$default)
credit_data$rel1 <- NULL
credit_data$rel2 <- NULL
credit_data$rel3 <- NULL
credit_data$pay_7 <- NULL
credit_data$payn <- NULL


credit_test <- transform4(credit_test, TRUE)

credit_data$pay_amt1 <- NULL
credit_data$pay_amt2 <- NULL
credit_data$pay_amt3 <- NULL
credit_data$pay_amt4 <- NULL
credit_data$pay_amt5 <- NULL
credit_data$pay_amt6 <- NULL
credit_data$pay_2 <- NULL
credit_data$pay_3 <- NULL
credit_data$pay_4 <- NULL
credit_data$pay_5 <- NULL
credit_data$pay_6 <- NULL
credit_data$pay_7 <- NULL
credit_data$bill_amt1 <- NULL
credit_data$bill_amt2 <- NULL
credit_data$bill_amt3 <- NULL
credit_data$bill_amt4 <- NULL
credit_data$bill_amt5 <- NULL
credit_data$bill_amt6 <- NULL
credit_data$sex <- NULL

credit_data$pay_0 <- as.factor(credit_data$pay_0)
credit_data$pay_2 <- as.factor(credit_data$pay_2)
credit_data$age <- as.factor(credit_data$age)

#one-hot
#all
creditdatam <- sparse.model.matrix(default ~ .-1, data = credit_data)
creditdata_label <- credit_data$default
creditdata_matrix <- xgb.DMatrix(data = as.matrix(creditdatam), label = creditdata_label)

#hypergrid
hyper_grid <- expand.grid(
  eta = c(0.01, 0.03),
  max_depth = c(5),
  min_child_weight = c(5,3),
    subsample = c(.5, .7),
    colsample_bytree = c(.5,.7),
  optimal_trees = 0,
  max_auc = 0
)
nrow(hyper_grid)
for (i in 1:nrow(hyper_grid)) {
  hparams <- list(
    eta = hyper_grid$eta[i],
    max_depth = hyper_grid$max_depth[i],
    min_child_weight = hyper_grid$min_child_weight[i]
  )
  xgb3 <- xgb.cv(
    params = hparams,
    data = creditdata_matrix,
    nrounds = 3000,
    nfold = 5,
    objective = "multi:softprob",
    eval_metric = "auc",
    num_class = 2,
    early_stopping_rounds = 30
  )
  
  hyper_grid$optimal_trees[i] <- which.max(xgb3$evaluation_log$test_auc_mean)
  hyper_grid$max_auc[i] <- max(xgb3$evaluation_log$test_auc_mean)
}

