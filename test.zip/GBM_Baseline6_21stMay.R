# Revise baseline 6 again, 
# > Consider merging pay_05, pay_04, pay_06 - it doesn't make sense for them to mess up in order indicates low importance 
# > Consider removing bill_increase 2,3,4 as we have observed they were no difference in partial dependency plot -> nope
# > pay 6 and pay 5 counts we can also consider removing. -> no effect
# pay_0 5 and 6 could be merged as well

# Load Libraries ----
library(here)
library(tidyverse)
library(janitor)
library(caret)
library(gbm)
library(ROCR)
library(parallel)
library(doParallel)
library(pROC) # For calculating AUC

# Load data sets ----
credit_data <- read_csv(here("data", "AT2_credit_train.csv"))
credit_test <- read_csv(here("data", "AT2_credit_test.csv"))

cluster = makeCluster(detectCores() - 2) # convention to leave 1 core for OS
registerDoParallel(cluster)
cluster

# Cleaning ----
get_pay_amount_fluctuations <- function(row_data, up){
  pay_amt_up = 0
  pay_amt_down = 0
  pay_amt_variables <- c("pay_amt1","pay_amt2","pay_amt3","pay_amt4","pay_amt5","pay_amt6")
  counter = length(pay_amt_variables)
  while(counter > 1){
    if(row_data[pay_amt_variables[counter]] - row_data[pay_amt_variables[counter-1]] > 0){
      pay_amt_up = pay_amt_up + 1
    } else if(row_data[pay_amt_variables[counter]] - row_data[pay_amt_variables[counter-1]] < 0){
      pay_amt_down = pay_amt_down + 1
    }
    counter = counter - 1
  }
  
  if(up){
    return(pay_amt_up)
  } else {
    return(pay_amt_down)
  }
}

get_pay_fluctuations <- function(row_data, up){
  pay_up = 0
  pay_down = 0
  pay_variables <- c("pay_0", "pay_2", "pay_3", "pay_4", "pay_5", "pay_6")
  counter = length(pay_variables)
  while(counter > 1){
    previousWeek <- 0
    currentWeek <- 0
    
    if(row_data[pay_variables[counter]] > 0){
      previousWeek <- 1
    }
    if(row_data[pay_variables[counter-1]] > 0){
      currentWeek <- 1
    }
    
    if(previousWeek - currentWeek > 0){
      pay_up = pay_up + 1
    } else if(previousWeek - currentWeek < 0){
      pay_down = pay_down + 1
    }
    counter = counter - 1
  }
  
  if(up){
    return(pay_up)
  } else {
    return(pay_down)
  }
}

get_total_value <- function(row_data, value){
  count = 0
  for(data in row_data){
    if(data == value){
      count = count + 1
    }
  }
  return(count)
}

transform4 <- function(temp_data, keep_id){
  # Basic Clean ----
  temp_data <- temp_data %>%
    clean_names() %>% 
    filter(sex==1|sex==2) %>% #-------------- Task 5 & 6: Remove the few bad sex records
    filter(limit_bal>=0) %>% #---------------- Remove negative credit
    filter(age < 100) # ---------------------- %>% # Age 157 might be some kind of typo
  
  if(!keep_id){
    temp_data <- temp_data %>%
      select(-id) #------------------------ TASK 4: ID is present, so we need to just drop that column as well
    temp_data$default <- as.factor(temp_data$default)
  }
  
  # pay amount ----
  # Because based on importance, it is the least important we want to make some
  # more meaning out of it - because it should at some level indicate defaulting
  pay_amt_variables <- c("pay_amt1","pay_amt2","pay_amt3","pay_amt4","pay_amt5","pay_amt6")
  pay_variables <- c("pay_0", "pay_2", "pay_3", "pay_4", "pay_5", "pay_6")
  temp_data <- temp_data %>%
    mutate_at(pay_amt_variables, .funs = function(x) replace(x, x > 0, 1)) %>%
    mutate(repayments = rowSums(across(pay_amt_variables)))
  
  # pay amount fluctuations
  temp_data <- temp_data %>%
    mutate(pay_amt_up = apply(across(pay_amt_variables), 1, function(x) get_pay_amount_fluctuations(x, TRUE))) %>%
    mutate(pay_amt_down = apply(across(pay_amt_variables), 1, function(x) get_pay_amount_fluctuations(x, FALSE)))
  
  
  # bill amount ----
  # bill increase and bill amount average instead of bill amount ----
  temp_data <- temp_data %>%
    mutate(bill_increase1 = get("bill_amt1")-get("bill_amt2")) %>%
    mutate(bill_increase2 = get("bill_amt1")-get("bill_amt3")) %>%
    mutate(bill_increase3 = get("bill_amt1")-get("bill_amt4")) %>%
    mutate(bill_increase4 = get("bill_amt1")-get("bill_amt5")) %>%
    mutate(bill_increase5 = get("bill_amt1")-get("bill_amt6")) %>%
    mutate(bill_average = rowMeans(across(starts_with("bill_amt"))))
  
  
  # merged_pay_count_variables <- c("pay_5_count", "pay_6_count")
  
  temp_data<- temp_data %>% 
    mutate(pay_n2_count = apply(across(pay_variables), 1, function(x) get_total_value(x, -2))) %>%
    mutate(pay_n1_count = apply(across(pay_variables), 1, function(x) get_total_value(x, -1))) %>%
    mutate(pay_0_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 0))) %>%
    mutate(pay_1_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 1))) %>%
    mutate(pay_2_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 2))) %>%
    mutate(pay_3_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 3))) %>%
    mutate(pay_4_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 4))) %>%
    mutate(pay_5_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 5))) %>%
    mutate(pay_6_count = apply(across(pay_variables), 1, function(x) get_total_value(x, 6)))
  # mutate(pay_5plus_count = rowSums(across(merged_pay_count_variables)))
  
  # pay X ----
  
  # pay fluctuations
  temp_data <- temp_data %>%
    mutate(pay_up = apply(across(pay_variables), 1, function(x) get_pay_fluctuations(x, TRUE))) %>%
    mutate(pay_down = apply(across(pay_variables), 1, function(x) get_pay_fluctuations(x, FALSE)))
  
  # credit score 1
  temp_data <- temp_data %>%
    mutate(credit_score1 = rowSums(across(pay_variables)))
  
  # credit score 2 - based on -2 could indicate inactivity which is bad
  temp_data <- temp_data %>%
    mutate_at(pay_variables, .funs = function(x) replace(x, x == -1, -3)) %>%
    mutate_at(pay_variables, .funs = function(x) replace(x, x == 0, -1)) %>%
    mutate_at(pay_variables, .funs = function(x) replace(x, x == -2, 0)) %>%
    mutate_at(pay_variables, .funs = function(x) replace(x, x == -3, -2)) %>%
    mutate(credit_score2 = rowSums(across(pay_variables)))
  
  # Merging 6 into 5 essentially removing 6
  temp_data <- temp_data %>%
    mutate_at("pay_0", .funs = function(x) replace(x, x == 6, 5))
  
  # pay amount is also now a categorical variable
  categorical_variables <- c("marriage", "sex", "education", pay_amt_variables, pay_variables)
  
  temp_data[,categorical_variables] <- lapply(temp_data[,categorical_variables], factor)
  
  pay_variables_overfitting <- c("pay_2", "pay_3", "pay_4", "pay_5", "pay_6")
  bill_amount_overfitting <- c("bill_amt3", "bill_amt4", "bill_amt5", "bill_amt6")
  overfitting_pay_count_variables <- c("pay_5_count", "pay_6_count")
  
  overfitting_variables <- c(pay_amt_variables, pay_variables_overfitting, bill_amount_overfitting, overfitting_pay_count_variables)
  temp_data <- temp_data %>%
    select(-overfitting_variables)
  
  temp_data <- temp_data %>%
    relocate(default)
  
  return(temp_data)
}

credit_data <- transform4(credit_data, FALSE)
credit_test <- transform4(credit_test, TRUE)


# Partition Data ----
set.seed(1);
train_indices <- createDataPartition(y = credit_data$default, p = 0.8, list = F)
training = credit_data[train_indices , ]
testing = credit_data[-train_indices, ]

# Design Model ----
fitControl <- trainControl(
  method = 'cv',                   # k-fold cross validation
  number = 10,                      # number of folds
  savePredictions = 'final',       # saves predictions for optimal tuning parameter
  classProbs = T,                  # should class probabilities be returned
  summaryFunction=twoClassSummary  # results summary function
) 
gbm_model <- train(default ~., 
                   data = training,
                   method = 'gbm',
                   metric = "ROC",
                   # tuneLength = 5,
                   # tuneGrid = expand.grid(
                   #   interaction.depth = c(4, 7, 10, 14, 16),
                   #   n.trees = c(400, 600, 800, 1000, 1200, 1400, 1600, 1800),
                   #   shrinkage = c(0.01, 0.005),
                   #   n.minobsinnode = c(45, 50, 55)),
                   tuneGrid = expand.grid(
                     interaction.depth = 14,
                     n.trees = 1600,
                     shrinkage = 0.005,
                     n.minobsinnode = 50),
                   trControl = fitControl)




# Evaluation ----
print(gbm_model); 
model_results <- gbm_model$results; write_csv(model_results, here("output", sprintf('%s_model_tuning_results.csv', Sys.time())))
plot(gbm_model);
plot(varImp(gbm_model));

## Confusion Matrix Comparison ----

target_col <- grep("default",names(credit_data)) # Identify position of target column

# Train
training$predictions <- predict(gbm_model,training[,-target_col])
# cbind(training$predictions, training$default)
table(training$predictions, training$default)

# Test
testing$predictions <- predict(gbm_model,testing[,-target_col])
# cbind(testing$predictions, testing$default)
table(testing$predictions, testing$default)

##  Caret's Evaluation Metrics ----
testing$predictions <- predict(gbm_model, newdata = testing[, -target_col])
#testing$probability <- predict(gbm_model, testing, type="prob", method="class")
caret::confusionMatrix(data = testing$predictions, 
                       reference = testing$default,
                       mode = "everything", 
                       positive = "Y")

# ?tolerance ----
simpleOne <- tolerance(gbm_model$results, metric = "ROC", tol = 2.5, maximize = TRUE)
gbm_model$results[simpleOne, 1:6]

## My evaluation metrics function ----
#pred - predicted class
#predprob = predicted class probabilities (ADD THIS)
#actual - actual class
my_evaluation <- function(pred, actual, predprob){
  # Create a confusion matrix (along with other measures) using the table function
  cfm <- table(predicted=pred,true=actual)
  cfm
  # TN|FN
  # FP|TP
  TN <- cfm[1,1]
  FN <- cfm[1,2]
  FP <- cfm[2,1]
  TP <- cfm[2,2]
  
  print(cfm)
  
  #Accuracy
  accuracy <- (TP+TN)/sum(cfm)
  
  #Precision = TP/(TP+FP)
  precision <- TP/(TP+FP)
  
  #Recall = TP/(TP+FN)
  recall <- TP/(TP + FN)
  
  #F1
  f1 <- 2*(precision*recall/(precision+recall))
  
  #AUC
  auc <- auc(actual, predprob)
  
  evaluation_metrics <- data.frame(
    accuracy,
    precision,
    recall,
    f1,
    auc
  )
  
  return(evaluation_metrics)
}
training$probability <- predict(gbm_model, training, type="prob", method="class")
testing$probability <- predict(gbm_model, testing, type="prob", method="class")
my_evaluation(as.numeric(training$predictions), as.numeric(training$default), as.numeric(training$probability$Y))
my_evaluation(as.numeric(testing$predictions), as.numeric(testing$default), as.numeric(testing$probability$Y))

pred_ROCR <- prediction(testing$probability$Y, testing$default)
auc_ROC <- performance(pred_ROCR, measure = "auc")
auc_ROC <- auc_ROC@y.values[[1]]
auc_ROC

# Partial Dependencies ----
pdp::partial(gbm_model, pred.var = "age", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "credit_score1", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "pay_0", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "pay_2_count", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "limit_bal", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "bill_average", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "bill_amt1", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "bill_increase5", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "bill_increase1", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "bill_increase2", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "bill_increase4", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "bill_increase3", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
pdp::partial(gbm_model, pred.var = "credit_score2", plot = TRUE, rug = TRUE, type="classification", prob=TRUE, parallel=F, which.class = "Y", train=training)
# Validation Set ----
credit_test$probability <- predict(gbm_model, credit_test, type="prob", method="class")
to_export <- credit_test[c("id", "probability")]
to_export <- rename(to_export, "ID"="id")
to_export$default <- to_export$probability[,2]
to_export$probability <- NULL

write_csv(to_export, here("data", "baseline6_gbm_11_pay-fluctuations.csv"))

# Big training based on adds only bill amount back ----
# The final values used for the model were n.trees = 1600, interaction.depth = 14, shrinkage = 0.005 and n.minobsinnode = 50.

# More tuning ----
# 1 12745  2296
# 2   825  2600
# accuracy precision    recall        f1       auc
# 1 0.8309867 0.7591241 0.5310458 0.6249249 0.8515373

# 1 3130  615
# 2  262  608
# 1 0.8099675 0.6988506 0.4971382 0.5809842 0.8040329
# The final values used for the model were n.trees = 800, interaction.depth = 14, shrinkage = 0.01 and n.minobsinnode = 45.

# Edwin's pay variables ----
# n.trees = 1600, interaction.depth = 14, shrinkage = 0.005 and n.minobsinnode = 50.
# 1 12744  2295
# 2   826  2601
# accuracy precision  recall       f1       auc
# 1 0.8309867 0.7589729 0.53125 0.625015 0.8514963

# 1 3130  618
# 2  262  605
# 1 0.8093174 0.6978085 0.4946852 0.5789474 0.8041263